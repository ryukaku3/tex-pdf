run this command in here.

# debuild -uc -us -b
