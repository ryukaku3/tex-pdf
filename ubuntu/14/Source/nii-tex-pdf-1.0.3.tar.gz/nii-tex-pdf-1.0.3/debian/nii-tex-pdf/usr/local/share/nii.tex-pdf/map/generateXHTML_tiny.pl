#!/usr/bin/perl

use strict;
use warnings;

use JSON;
use KyotoCabinet;

use xml::XHTMLFormatter;

use config::JsonConfig;

my $config = config::JsonConfig::load('map');

my $uid = $ARGV[0];

my $db = new KyotoCabinet::DB();

$db->open($config->{dbPath},
	  KyotoCabinet::DB::OREADER)
    or die $db->error;

my $info = $db->get($uid);

$db->close();

unless(defined($info)) {
    die "Not found.\n";
}

print xml::XHTMLFormatter::format(JSON::decode_json($info));

exit(0);
