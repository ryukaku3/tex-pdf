use strict;
use warnings;

use KyotoCabinet;
use JSON;

use config::JsonConfig;


package pdf::Api;

package pdf::Api::Local;

sub new
{
    my ($class, $dbPath) = @_;

    unless(defined($dbPath)) {
	die 'db path not specified.';
    }

    my $config = config::JsonConfig::load('PDF');

    my $dbConfig = $config->{dbParams};
    unless(defined($dbConfig)) {
	$dbConfig = '';
    }
    my $db = new KyotoCabinet::DB();

    $db->open($dbPath.'#dfunit=65536'.$dbConfig,
	      KyotoCabinet::DB::OREADER)
	or die $db->error;
      
    return bless {
	db => $db
    }, $class;
}

sub DESTROY
{
    my ($self) = @_;
    if(defined($self->{db})) {
	$self->{db}->close();
    }
}

sub getArticleInfo
{
    my ($self, $pdfid) = @_;
    return JSON::decode_json($self->{db}->get($pdfid));
}


package xml::Api::JsonRPC;

1;
