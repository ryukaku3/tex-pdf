#!/usr/bin/perl

use strict;
use warnings;

use constant DEBUG => 0;

use JSON;
use LWP::UserAgent;
use Encode;
use XML::LibXML;

use config::JsonConfig;

use id::Manager;
use map::Api;

my $idConfig = config::JsonConfig::load('id');
my $idManager = new id::Manager($idConfig->{dbPath});

my $mapConfig = config::JsonConfig::load('map');

my $mapApi = new map::Api::Local($mapConfig->{dbPath},
                                  $mapConfig->{boundaryDbPath},
                                  $mapConfig->{boundaryIndexDbPath},
                                  $mapConfig->{filterIndexDbPath});

$idManager->doForAll(\&forEachArticle);

exit(0);

# --------------------------------


sub forEachArticle {

    my ($self, $uid, $pdfid, $xmlid) = @_;

    my $result = $mapApi->getBoundaries($uid);
    while(my ($filterStr, $filterInfo) =  each(%{$result})) { # for each citation

	# - ignore unless citation

	# - sort boundaries by id, concat text
	my $text = join('', (map {$filterInfo->{$_}->{text}}  (sort(keys(%$filterInfo)))));
	# - i-linkage
#	print Encode::encode('utf-8', $text), "\n";

	if(1) {
	my $url = searchByIlinkage($text);
	# - output result

	unless(defined($url)) {
	    $url = '';
	}
	print join("\t", ($uid, $filterStr, $url)), "\n";
	}
    }
}


sub searchByIlinkage
{
    my ($citation) = @_;

    my $maxNumOfCandidates = 1;

    my $ua = new LWP::UserAgent();
#    my $req = new HTTP::Request(POST=>'http://localhost:9780/cilink_demo/cgi-bin/plus/plus/cgi-bin/i-linkage.cgi'); # FIXME: variable; this is for kanga
    my $req = new HTTP::Request(POST=>'http://localhost/cilink_demo/cgi-bin/plus/plus/cgi-bin/i-linkage.cgi'); # FIXME: variable; this is for kanga
    $req->content_type('application/x-www-form-urlencoded');
    $req->content('q='.URI::Escape::uri_escape_utf8($citation).'&c='.$maxNumOfCandidates.'&m=0');
    $req->authorization_basic('guest', 'i2nic'); # FIXME: variable

    my $response = $ua->request($req);

    unless($response->is_success) {
	return undef;
    }
    {
	my $xmlStr = $response->decoded_content;

	if(DEBUG) {
	    open(my $log, '>>', '/tmp/ILinkage.log');
	    print $log "--------------------------------\n", $xmlStr, "\n\n";
	    close($log);
	}
	

	my $dom = XML::LibXML->load_xml(string=>$xmlStr);
	my @resultElms = $dom->getElementsByTagName('result');

	my $candidateURL = undef;
	my $candidateScore = 0;

	if(int(@resultElms) < 1) {

	    warn "No results. skipped.\n";
	    next;
	}

	foreach my $resultElm (@resultElms) {
	    unless($resultElm->parentNode != $dom) {
		warn "internal error: internal function returns unexpected result (no result elements)\n";
		next;
	    }

	    my @itemElms = $resultElm->getElementsByTagName('item');
	    foreach my $item (@itemElms) {

		#- check
		unless($item->parentNode->parentNode->isSameNode($resultElm)) {
		    warn "internal error: internal function returns unexpected result (out of expected schema)\n";
		    next;
		}

		#- convert
		my $score = getUniqueChildNode($item, 'score');
		next unless(defined($score));

		my $url = getUniqueChildNode($item, 'url');
		next unless(defined($url));

		if($candidateScore < $score->textContent) {

		    $candidateScore = $score->textContent;
		    $candidateURL = $url->textContent;
		}
	    }
	}
	return $candidateURL;
    }
}

sub getUniqueChildNode {
    my ($parentElm, $tagName) = @_;

    my @candidates = $parentElm->getChildrenByTagName($tagName);
    unless(scalar(@candidates) <= 1) {
	die;
    }
    if(scalar(@candidates) == 1) {
	return $candidates[0];
    }
    # not found
    return undef;
}
