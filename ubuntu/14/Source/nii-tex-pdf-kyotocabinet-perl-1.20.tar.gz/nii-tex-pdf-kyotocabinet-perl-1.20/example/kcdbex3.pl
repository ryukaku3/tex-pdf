use KyotoCabinet;

# tie a hash variable to the database
my $db = tie(my %db, 'KyotoCabinet::DB', 'casket.kch');

# store records
$db{'foo'} = 'hop';   # string is fundamental
$db{bar} = 'step';    # omitting quotation is ok
$db{3} = 'jump';      # number is also ok

# retrieve a record value
printf("%s\n", $db{'foo'});

# update records in transaction
$db->transaction(sub {
    $db{'foo'} = 2.71828;
    1;
});

# multiply a record value
$db->accept('foo', sub {
    my ($key, $value) = @_;
    $value * 2;
});

# traverse records by iterator
while (my ($key, $value) = each(%db)) {
    printf("%s:%s\n", $key, $value);
}

# upcase values by iterator
$db->iterate(sub {
    my ($key, $value) = @_;
    uc($value);
});

# traverse records by cursor
$db->cursor_process(sub {
    my ($cur) = @_;
    $cur->jump;
    while ($cur->accept(sub {
            my ($key, $value) = @_;
            printf("%s:%s\n", $key, $value);
            KyotoCabinet::Visitor::NOP;
        })) {
        $cur->step;
    }
});

# untie the hash variable
undef($db);
untie(%db);
