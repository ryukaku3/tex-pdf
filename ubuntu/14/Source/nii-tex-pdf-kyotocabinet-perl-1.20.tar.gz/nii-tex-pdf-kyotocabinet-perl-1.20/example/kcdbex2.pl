use KyotoCabinet;

# create the database object
my $db = new KyotoCabinet::DB;

# open the database
if (!$db->open('casket.kch', $db->OREADER)) {
    printf STDERR ("open error: %s\n", $db->error);
}

# define the visitor
{
    package VisitorImpl;
    use base qw(KyotoCabinet::Visitor);
    # constructor
    sub new {
        my $self = new KyotoCabinet::Visitor;
        bless $self;
        return $self;
    }
    # call back function for an existing record
    sub visit_full {
        my ($self, $key, $value) = @_;
        printf("%s:%s\n", $key, $value);
        return $self->NOP;
    }
    # call back function for an empty record space
    sub visit_empty {
        my ($self, $key) = @_;
        printf STDERR ("%s is missing\n", $key);
        return $self->NOP;
    }
}
my $visitor = new VisitorImpl;

# retrieve a record with visitor
if (!$db->accept("foo", $visitor, 0) ||
    !$db->accept("dummy", $visitor, 0)) {
    printf STDERR ("accept error: %s\n", $db->error);
}

# traverse records with visitor
if (!$db->iterate($visitor, 0)) {
    printf STDERR ("iterate error: %s\n", $db->error);
}

# close the database
if (!$db->close) {
    printf STDERR ("close error: %s\n", $db->error);
}
