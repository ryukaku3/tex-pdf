use strict;
use warnings;

use id::Manager;
use config::JsonConfig;

my $pdfConfig = config::JsonConfig::load('PDF');

my $idConfig = config::JsonConfig::load('id');
my $idManager = new id::Manager($idConfig->{dbPath});

my $db = new KyotoCabinet::DB();
$db->open($pdfConfig->{'dbPath'},
	  KyotoCabinet::DB::OREADER)
    or die $db->error;

my $cur = $db->cursor;
$cur->jump;
while(my ($pdfid, $value) = $cur->get(1)) {
    my $ids = mapFunction($pdfid);
    $idManager->register(@$ids);
}

$cur->disable;
$db->close();

exit(0);

# --------------------------------
sub mapFunction # FIXME
{
    my ($pdfid) = @_;
    my ($uid) = ($pdfid =~ /^(.+)\.pdf/);
    unless(defined($uid)) {
	die $pdfid." seems no pdf id.";
    }
    my $xmlid = $uid.'.xml';
    return [$uid, $pdfid, $xmlid];
}
