use strict;
use warnings;

use id::Manager;
use map::Mapper;
use config::JsonConfig;
use pdf::Api;
use xml::Api;

my $idConfig = config::JsonConfig::load('id');
my $xmlConfig = config::JsonConfig::load('XML');
my $pdfConfig = config::JsonConfig::load('PDF');
my $mapConfig = config::JsonConfig::load('map');

my $xmlAPI = new xml::Api::Local($xmlConfig->{dbPath});
my $pdfAPI = new pdf::Api::Local($pdfConfig->{dbPath});
my $mapper = new map::Mapper($mapConfig->{dbPath});

my $skip = 1;

my $DEBUG_SINGLE_DOC = 0;

my $idManager = new id::Manager($idConfig->{dbPath});
$idManager->doForAll(
    sub{
	my ($self, $uid, $pdfid, $xmlid) = @_;

	return if($mapper->isStored($uid));

	my $xmlInfo = $xmlAPI->getArticleInfo($xmlid);
	my $pdfInfo = $pdfAPI->getArticleInfo($pdfid);

	return unless(defined($xmlInfo));
	return unless(defined($pdfInfo));

	print "- ", $uid, "\n";

	if($DEBUG_SINGLE_DOC) {
	    if($uid eq '1_1_21') {
		$skip = 0;
	    }

	    if($skip) {
		return;
	    }
	}

	eval {

	    my $mergedInfo = $mapper->mapPdfAndXml($xmlInfo, $pdfInfo);
	    $mapper->store($uid, $mergedInfo);
	};
	if($@) {
	    warn $@;
	}
	if($DEBUG_SINGLE_DOC) {
	    exit(0);
	}

    }, undef);

exit(0);
