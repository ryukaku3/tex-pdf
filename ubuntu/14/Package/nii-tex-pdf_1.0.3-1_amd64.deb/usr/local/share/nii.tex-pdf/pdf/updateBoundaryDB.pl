#!/usr/bin/perl
use strict;
use warnings;

use pdf::BoundaryDB;

use KyotoCabinet;
use JSON;

use config::JsonConfig;

my $config = config::JsonConfig::load('PDF');
my $idConfig = config::JsonConfig::load('id');
my $idManager = new id::Manager($idConfig->{dbPath});

my $pdfDB = new KyotoCabinet::DB();
$pdfDB->open($config->{'dbPath'},
	     KyotoCabinet::DB::OREADER)
    or die $pdfDB->error;

my $boundaryDB = new KyotoCabinet::DB();
$boundaryDB->open($config->{'boundaryDbPath'},
		  KyotoCabinet::DB::OCREATE |
		  KyotoCabinet::DB::OWRITER)
    or die $boundaryDB->error;

pdf::BoundaryDB::rebuild($idManager, $pdfDB, $boundaryDB);

$boundaryDB->close();
$pdfDB->close();

exit(0);
