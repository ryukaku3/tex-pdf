
use strict;
use warnings;

use File::Find;
use Cwd;

use config::JsonConfig;

use xml::z39_96::Importer;

my $cwd = Cwd::getcwd();

my $config = config::JsonConfig::load('XML/z39.96');
my $xmlDirpath = $config->{'XML dirpath'};
my $dbPath = $config->{'dbPath'};
# -
my $importer = new xml::z39_96::Importer($dbPath);

File::Find::find(
    sub{
	return unless ($_ =~ /\.xml$/);
	
	# File::Find modifies cwd, and it prevents JsonConfig from searching config files.
	my $finderCwd = Cwd::getcwd();
	chdir($cwd);

	print $File::Find::name, "\n";

	open(my $srcFH, '<', $File::Find::name)
	    or die "Opening $_  failed.";

	my @lines = <$srcFH>;
	close($srcFH);
	my $xmlStr = join('', @lines);

	my $articleInfo = $importer->convert($xmlStr);
	my $articleID = substr($File::Find::name, length($xmlDirpath));
	$importer->store($articleID, $articleInfo);

	chdir($finderCwd);
    },
    $xmlDirpath);

exit(0);

#--------------------------------
