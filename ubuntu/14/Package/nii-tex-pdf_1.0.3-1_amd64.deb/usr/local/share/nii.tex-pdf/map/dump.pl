#!/usr/bin/perl

use strict;
use warnings;

use JSON;
use LWP::UserAgent;
use Encode;
use XML::LibXML;

use config::JsonConfig;

use id::Manager;
use map::Api;

my $idConfig = config::JsonConfig::load('id');
my $idManager = new id::Manager($idConfig->{dbPath});

my $mapConfig = config::JsonConfig::load('map');

my $mapApi = new map::Api::Local($mapConfig->{dbPath},
                                  $mapConfig->{boundaryDbPath},
                                  $mapConfig->{boundaryIndexDbPath},
                                  $mapConfig->{filterIndexDbPath});

$idManager->doForAll(\&forEachArticle);

exit(0);

# --------------------------------


sub forEachArticle {

    my ($self, $uid, $pdfid, $xmlid) = @_;

    my $result = $mapApi->getBoundaries($uid);

    if(defined($result)) {
	print $uid, "\t", JSON::encode_json($result), "\n";
    }
}
