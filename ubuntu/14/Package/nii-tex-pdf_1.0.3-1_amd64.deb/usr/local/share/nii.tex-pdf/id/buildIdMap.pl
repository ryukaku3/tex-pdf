
use strict;
use warnings;

use id::Manager;
use config::JsonConfig;

my $pdfConfig = config::JsonConfig::load('PDF');

my $idConfig = config::JsonConfig::load('id');
my $idManager = new id::Manager($idConfig->{dbPath});

open(my $id_map_tsv_FH, '<', $pdfConfig->{'id_map.tsv filepath'})
    or die $?;

while(<$id_map_tsv_FH>) {
    my $ids = mapFunction($_);
    $idManager->register(@$ids);
}

close($id_map_tsv_FH);

exit(0);

# --------------------------------
sub mapFunction # FIXME
{
    my ($id_map_line) = @_;
    chomp($id_map_line);
#    my ($xhtmlId, $pdfId) = ($id_map_line =~ /^[^\/]+\/(.+)\.tex\s+(.+)$/);
    my ($xhtmlId, $pdfId) = ($id_map_line =~ /^.*?([^\/]+)\.tex\s+(.+)$/);
    unless(defined($pdfId)) {
	die $id_map_line." seems not to contain pdf id.";
    }
#    return [$pdfId, $pdfId.'.pdf', $xhtmlId.'.xhtml'];
    return [$pdfId, $pdfId.'.pdf', $xhtmlId.'.html'];
}
