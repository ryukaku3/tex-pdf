#!/usr/bin/perl

use strict;
use warnings;

use File::Find;
use Cwd;

use config::JsonConfig;

use xml::Importer;

my $cwd = Cwd::getcwd();

my $config = config::JsonConfig::load('XML');
my $xmlDirpath = $config->{'XML dirpath'};
my $dbPath = $config->{'dbPath'};
# -
my $importer = new xml::Importer($dbPath);

File::Find::find(
    sub{
	return unless ($_ =~ /html$/);
	
	# File::Find modifies cwd, and it prevents JsonConfig from searching config files.
	my $finderCwd = Cwd::getcwd();
	chdir($cwd);

#	print $File::Find::name, "\n";

	open(my $srcFH, '<', $File::Find::name)
	    or die "Opening $_  failed.";

	my @lines = <$srcFH>;
	close($srcFH);
	my $xmlStr = join('', @lines);

	unless($xmlStr =~ /^\s+$/) {

	    my $articleID = substr($File::Find::name, length($xmlDirpath));

	    return if($importer->isStored($articleID));
	    eval {
		my $articleInfo = $importer->convert($xmlStr);
		$importer->store($articleID, $articleInfo);
	    };
	    if($@) {
		warn $@;
	    }
	}

	chdir($finderCwd);
    },
    $xmlDirpath);

exit(0);

#--------------------------------
