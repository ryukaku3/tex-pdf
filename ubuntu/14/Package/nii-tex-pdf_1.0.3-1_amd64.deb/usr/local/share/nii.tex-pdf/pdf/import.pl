
use strict;
use warnings;

use File::Find;
use Cwd;

use config::JsonConfig;

use pdf::Parser;
use pdf::PdfxmlImporter;

use constant SCALE => 2.0;

my $cwd = Cwd::getcwd();

my $config = config::JsonConfig::load('PDF');
my $pdfDirpath = $config->{'PDF dirpath'};
my $dbPath = $config->{'dbPath'};
# -
my $importer = new pdf::PdfxmlImporter($dbPath);

File::Find::find(
    sub{
	return unless ($_ =~ /\.pdf$/);
	
	# File::Find modifies cwd, and it prevents JsonConfig from searching config files.
	my $finderCwd = Cwd::getcwd();
	chdir($cwd);

	print $File::Find::name, "\n";

	my $xmlStr = pdf::Parser::parseFile($File::Find::name, SCALE);
	unless(length($xmlStr) > 0) {
	    warn "$_ looks non-PDF. Skipped.";
	    chdir($finderCwd);
	    return;
	}
	my $articleInfo = $importer->convert($xmlStr, SCALE);
	my $articleID = substr($File::Find::name, length($pdfDirpath));
	$importer->store($articleID, $articleInfo);

	chdir($finderCwd);
    },
    $pdfDirpath);

exit(0);

#--------------------------------
