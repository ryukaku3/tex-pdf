use strict;
use warnings;

package map::Api_JsonRpc;
#use base qw(JSON::RPC::Legacy::Procedure);

use lib '/home/tkana/src/nii.tex-pdf/backend';
use YAML;
use JSON;
use KyotoCabinet;
use Data::Dumper;

use config::JsonConfig;

use map::Api;

sub new
{
    my ($class) = @_;

    my $config = config::JsonConfig::load('map');
    my $db = new KyotoCabinet::DB();
    my $boundaryDb = new KyotoCabinet::DB();
    my $boundaryIndexDb = new KyotoCabinet::DB();
    my $filterIndexDb = new KyotoCabinet::DB();

    return bless { config=>$config,
		   db=>$db,
		   boundaryDb=>$boundaryDb,
		   boundaryIndexDb=>$boundaryIndexDb,
		   filterIndexDb=>$filterIndexDb
    }, $class;
}

sub getBoundaryInfo {

    my ($self, $params, $procedure) = @_;

    if(ref($params) eq 'ARRAY') {
	my $_params = {};

	my @fields = qw / articleUUID boundaryIDs /;
	for(my $i = 0; $i < int(@fields); $i++) {
	    $_params->{$fields[$i]} = $params->[$i];
	}
	$params = $_params;
    }

    my $api = new map::Api::Local(undef, $self->{config}->{boundaryDbPath});
    return $api->getBoundaryInfo($params->{articleUUID}, $params->{boundaryIDs});
}

# return Hash

sub getBoundaries {
    my ($self, $params, $procedure) = @_;

    if(ref($params) eq 'ARRAY') {
	my $_params = {};

	my @fields = qw / articleUUID page filter /;
	for(my $i = 0; $i < int(@fields); $i++) {
	    $_params->{$fields[$i]} = $params->[$i];
	}
	$params = $_params;
    }

    my $api = new map::Api::Local($self->{config}->{dbPath},
				  $self->{config}->{boundaryDbPath},
				  $self->{config}->{boundaryIndexDbPath},
				  $self->{config}->{filterIndexDbPath});

    return $api->getBoundaries($params->{articleUUID}, $params->{page}, $params->{filter});
}

# return Array

sub getBoundaryIDs {

    my ($self, $params, $procedure) = @_;

    if(ref($params) eq 'ARRAY') {
	my $_params = {};

	my @fields = qw / articleUUID page filter /;
	for(my $i = 0; $i < int(@fields); $i++) {
	    $_params->{$fields[$i]} = $params->[$i];
	}
	$params = $_params;
    }

    my $api = new map::Api::Local(undef, undef, $self->{config}->{boundaryIndexDbPath});

    return $api->getBoundaryIDs($params->{articleUUID},
				$params->{page},
				$params->{filter});
}

sub getArticleAsXML {

    my ($self, $params, $procedure) = @_;

    if(ref($params) eq 'ARRAY') {
	my $_params = {};

	my @fields = qw / articleUUID /;
	for(my $i = 0; $i < int(@fields); $i++) {
	    $_params->{$fields[$i]} = $params->[$i];
	}
	$params = $_params;
    }

    require xml::XHTMLFormatter;

    $self->{db}->open($self->{config}->{dbPath},
	      KyotoCabinet::DB::OREADER)
	or die $self->{db}->error;

    my $info = $self->{db}->get($params->{articleUUID});

    $self->{db}->close();
    
    unless(defined($info)) {
	die { message => "Not found.", code=>404 };
    }
#    warn "params: ".YAML::Dump($params). "\n";

    return {"xhtml"=>xml::XHTMLFormatter::format(JSON::decode_json($info))};
}

sub getAvailableFilterConditions
{
    my ($self, $params, $procedure) = @_;

    if(ref($params) eq 'ARRAY') {
	my $_params = {};

	my @fields = qw / articleUUID page /;
	for(my $i = 0; $i < int(@fields); $i++) {
	    $_params->{$fields[$i]} = $params->[$i];
	}
	$params = $_params;
    }

    my $api =
	new map::Api::Local(undef, undef, undef, $self->{config}->{filterIndexDbPath});

    return $api->getAvailableFilterConditions($params->{articleUUID}, $params->{page});
}

1;
