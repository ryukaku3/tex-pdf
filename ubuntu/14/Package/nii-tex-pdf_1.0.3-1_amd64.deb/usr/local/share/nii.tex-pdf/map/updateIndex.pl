#!/usr/bin/perl

use strict;
use warnings;

use JSON;
use KyotoCabinet;

use config::JsonConfig;
use map::Index;

my $config = config::JsonConfig::load('map');

my $mergedDB = new KyotoCabinet::DB();
$mergedDB->open($config->{dbPath},
		KyotoCabinet::DB::OREADER)
    or die $mergedDB->error;

my $indexDB = new KyotoCabinet::DB();
$indexDB->open($config->{boundaryIndexDbPath},
	       KyotoCabinet::DB::OCREATE |
	       KyotoCabinet::DB::OWRITER |
	       KyotoCabinet::DB::OTRUNCATE)
    or die $indexDB->error;

my $index = new map::Index($indexDB);
my $cur = $mergedDB->cursor;
$cur->jump;
while (my ($key, $value) = $cur->get(1)) {
    $index->build(
	$key,
	JSON::decode_json($value),
	$config->{"filter name"},
	$config->{'pdf boundary element'}->{namespace}->{alias}.':'.$config->{'pdf boundary element'}->{'id attr name'},
	$config->{'pdf boundary element'}->{namespace}->{alias}.':'.$config->{'pdf boundary element'}->{'page attr name'});
}
$mergedDB->close();

$index->gatherForValues();
$index->gatherForPages();

$indexDB->close();

# - build filter index
{
    $indexDB->open($config->{boundaryIndexDbPath},
		   KyotoCabinet::DB::OREADER)
	or die $indexDB->error;

    my $filterIndexDB = new KyotoCabinet::DB();
    $filterIndexDB->open($config->{filterIndexDbPath},
			 KyotoCabinet::DB::OCREATE |
			 KyotoCabinet::DB::OWRITER |
			 KyotoCabinet::DB::OTRUNCATE)
	or die $filterIndexDB->error;

    my %map;
    # - gather

    my $cursor = $indexDB->cursor;
    $cursor->jump;
    while(my ($keyStr) = $cursor->get(1)) {
	my ($article, $page, $filter) = split(/\0/, $keyStr);
	next unless(defined($page) && defined($filter) && $filter ne '');

	{
	    my $map = $map{$article."\0".$page};
	    unless(defined($map)) {
		$map{$article."\0".$page} = $map = [];
	    }

	    push(@{$map}, $filter);
	}

	{
	    my $map = $map{$article};
	    unless(defined($map)) {
		$map{$article} = $map = {};
	    }

	    $map->{$filter} = 1;
	}
    }
    $indexDB->close();

    while(my ($key, $value) = each(%map)) {
	my $filterArray;
	if(ref($value) eq 'HASH') {
	    @{$filterArray} = keys(%{$value});
	} else {
	    $filterArray = $value;
	}

	$filterIndexDB->set($key, JSON::encode_json($filterArray));
    }


    $filterIndexDB->close();
}



exit(0);
