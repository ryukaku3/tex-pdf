
use strict;
use warnings;

use File::Basename;
use JSON;

package config::JsonConfig;

sub load {
    my ($name) = @_;

    unless(defined($name)) {
	die "config name unspecified.";
    }

    my $jsonPath = File::Basename::dirname($INC{'config/JsonConfig.pm'}).'/'.$name.'.json';
#    warn $jsonPath;
    open(my $jsonFile, '<', $jsonPath) || die 'Config file '.$jsonPath.' open failed. '.$!;
    my @lines = <$jsonFile>;
    close($jsonFile);

    my $data = JSON::decode_json(join('', @lines));

    return $data;
}

1;
