use strict;
use warnings;

use KyotoCabinet;
use XML::LibXML;
use JSON;

use config::JsonConfig;

package xml::z39_96::Importer;

sub new
{
    my ($class, $dbPath) = @_;

    unless(defined($dbPath)) {
	die 'db path not specified.';
    }

    my $config = config::JsonConfig::load('XML/z39.96');

    my $dbConfig = $config->{dbParams};
    unless(defined($dbConfig)) {
	$dbConfig = '';
    }
    my $db = new KyotoCabinet::DB();

    $db->open($dbPath.'#dfunit=65536'.$dbConfig,
	      KyotoCabinet::DB::OCREATE |	
	      KyotoCabinet::DB::OWRITER)
	or die $db->error;
      
    return bless {
	db => $db
    }, $class;
}

sub DESTROY
{
    my ($self) = @_;
    if(defined($self->{db})) {
	$self->{db}->close();
    }
}

sub convert
{
    my ($self, $xmlStr) = @_;

    my $articleInfo = {};
    $articleInfo->{pathlayer} = ['journal','volume','number','pp'];
    $articleInfo->{pathlabel} = ['','','',''];
    $articleInfo->{path} = ['','','',''];

    my $dom = XML::LibXML->load_xml(string => $xmlStr, load_ext_dtd=>0, no_network=>1);

    # See z39.96 reference: http://www.niso.org/apps/group_public/download.php/10904/z39.96-2012.pdf
    # - journal metadata (for header detection)
    my $journalMetaNodeXPath = new XML::LibXML::XPathExpression('//journal-meta');
    my ($journalMetaNode) = $dom->findnodes($journalMetaNodeXPath);

    {
	# -- article/front/journal-meta/journal-title-group/trans-title-group/trans-title
	my $transTitleXPath = new XML::LibXML::XPathExpression('journal-title-group/trans-title-group/trans-title');
	my ($transTitleNode) = $journalMetaNode->findnodes($transTitleXPath);
	if(defined($transTitleNode)) {
	    $articleInfo->{pathlabel}->[0] = 
		$articleInfo->{path}->[0] =
		asSingleLine(decodeStupidCharEntities($transTitleNode->textContent));
	}
    }
    # - article metadata (for header detection)
    my $articleMetaNodeXPath = new XML::LibXML::XPathExpression('//article-meta');
    my ($articleMetaNode) = $dom->findnodes($articleMetaNodeXPath);

    {
	# -- article/front/article-meta/volume
	my $volumeNodeXPath = new XML::LibXML::XPathExpression('volume');
	my ($volumeNode) = $articleMetaNode->findnodes($volumeNodeXPath);
	if(defined($volumeNode)) {
	    my $val = asSingleLine(decodeStupidCharEntities($volumeNode->textContent));
	    $articleInfo->{pathlabel}->[1] = 'Vol.'.$val;
	    $articleInfo->{path}->[1] = $val;
	}
    }

    {
	# -- article/front/article-meta/issue
	my $issueNodeXPath = new XML::LibXML::XPathExpression('issue');
	my ($issueNode) = $articleMetaNode->findnodes($issueNodeXPath);
	if(defined($issueNode)) {
	    my $val = asSingleLine(decodeStupidCharEntities($issueNode->textContent));
	    $articleInfo->{pathlabel}->[2] = 'No.'.$val;
	    $articleInfo->{path}->[2] = $val;
	}
    }

    {
	# -- article/front/article-meta/fpage
	# -- article/front/article-meta/lpage
	my $fpageNodeXPath = new XML::LibXML::XPathExpression('fpage');
	my ($fpageNode) = $articleMetaNode->findnodes($fpageNodeXPath);
	my $lpageNodeXPath = new XML::LibXML::XPathExpression('lpage');
	my ($lpageNode) = $articleMetaNode->findnodes($lpageNodeXPath);

	if(defined($fpageNode) && defined($lpageNode)) {
	    my $fpage = asSingleLine(decodeStupidCharEntities($fpageNode->textContent));
	    my $lpage = asSingleLine(decodeStupidCharEntities($lpageNode->textContent));

	    if($fpage eq $lpage) {
		$articleInfo->{pathlabel}->[3] = 'p.'.$fpage;
		$articleInfo->{path}->[3] = $fpage;
	    } else {
		$articleInfo->{pathlabel}->[3] = 'pp.'.$fpage.'-'.$lpage;
		$articleInfo->{path}->[3] = $fpage.'-'.$lpage;
	    }
	}
    }

    # - article title
    {
	my @titlesInfo;
	# -- article/front/article-meta/title-group/article-title
	my $articleTitleNodeXPath = new XML::LibXML::XPathExpression('.//article-title');
	my ($articleTitleNode) = $articleMetaNode->findnodes($articleTitleNodeXPath);
	if(defined($articleTitleNode)) {
	    push(@titlesInfo,
		 {'lang'=>$articleTitleNode->getAttribute('xml:lang'),
		  'string'=>asSingleLine(decodeStupidCharEntities($articleTitleNode->textContent))});
	}
	
	# -- article/front/article-meta/title-group/trans-title-group/trans-title
	my $transTitleNodeXPath = new XML::LibXML::XPathExpression('.//trans-title');
	my ($transArticleTitleNode) = $articleMetaNode->findnodes($transTitleNodeXPath);
	if(defined($transArticleTitleNode)) {
	    push(@titlesInfo,
		 {'lang'=>$transArticleTitleNode->getAttribute('xml:lang'),
		  'string'=>asSingleLine(decodeStupidCharEntities($transArticleTitleNode->textContent))});
	}

	if(int(@titlesInfo) > 0) {
	    $articleInfo->{title} = \@titlesInfo;	
	}
    }

    # - each person
    {
	my @persons;
	$articleInfo->{actors} = \@persons;

	my $contribNodeXPath = new XML::LibXML::XPathExpression('.//contrib');
	foreach my $contribNode ($articleMetaNode->findnodes($contribNodeXPath)) {

	    my $personInfo = {};
	    push(@persons, $personInfo);

	    # -- article/front/article-meta/contrib-group/contrib/@contrib-type
	    $personInfo->{role} = $contribNode->getAttribute('contrib-type');

	    # -- article/front/article-meta/contrib-group/contrib/name-alternatives/name
	    my $nameNodeXPath = new XML::LibXML::XPathExpression('name-alternatives/name')
;
	    my @names;
	    foreach my $nameNode ($contribNode->findnodes($nameNodeXPath)) {
		push(@names,
		     {
			 'lang'=>$nameNode->getAttribute('xml:lang'),
			 'string'=>asSingleLine(decodeStupidCharEntities($nameNode->textContent))
		     });
	    }
	    if(int(@names) > 0) {
		$personInfo->{name} = \@names;
	    }

	    # -- article/front/article-meta/contrib-group/contrib/xref
	    # TODO:

	    
	}
    }
    

    # - abstract
    {
	my @abstracts;
	my $abstractNodeXPath = new XML::LibXML::XPathExpression('.//abstract');
	my $transAbstractNodeXPath = new XML::LibXML::XPathExpression('.//trans-abstract');
	my $paragraphNodeXPath = new XML::LibXML::XPathExpression('p');

	my $getParagraphs = sub {
	    my ($refNode, $abstracts) = @_;
	    my @paragraphs;
	    foreach my $pNode ($refNode->findnodes($paragraphNodeXPath)) {
		push(@paragraphs, {'string'=>trim(asSingleLine(decodeStupidCharEntities($pNode->textContent)))});
	    }
	    if(int(@paragraphs) > 0) {
		my $abstract = {
		    paragraphs => \@paragraphs
		};
		push(@$abstracts, $abstract);
	    }
	};

	# -- article/front/article-meta/abstract
	foreach my $refNode ($articleMetaNode->findnodes($abstractNodeXPath)) {
	    $getParagraphs->($refNode, \@abstracts);
	}
	# -- article/front/article-meta/trans-abstract
	foreach my $refNode ($articleMetaNode->findnodes($transAbstractNodeXPath)) {
	    $getParagraphs->($refNode, \@abstracts);
	}

	if(int(@abstracts) > 0) {
	    $articleInfo->{description} = \@abstracts;
	}
    }
    # - keywords
    {
	# -- article/front/article-meta/kwd-group/kwd
	my $kwdNodeXPath = new XML::LibXML::XPathExpression('.//kwd');
	my @keywords;
	foreach my $kwdNode ($articleMetaNode->findnodes($kwdNodeXPath)) {
	    push(@keywords,
		 {
		     'lang'=>$kwdNode->parentNode()->getAttribute('xml:lang'),
		     'string'=>asSingleLine(decodeStupidCharEntities($kwdNode->textContent))
		 });
	}
	if(int(@keywords)) {
	    $articleInfo->{keyword} = \@keywords;
	}
    }

    # - refs
    {
	my @refs;

	my $refNodeXPath = new XML::LibXML::XPathExpression('//ref-list/ref');
	my $labelNodeXPath = new XML::LibXML::XPathExpression('label');
	my $mixedCitationNodeXPath = new XML::LibXML::XPathExpression('mixed-citation');

	foreach my $refNode ($dom->findnodes($refNodeXPath)) {
	    my $refInfo = {};
	    push(@refs, $refInfo);

	    # -- article/back/ref-list/ref/@id
	    my $refid = $refNode->getAttribute('id');
	    if(defined($refid)) {
		$refInfo->{id} = $refid;
	    }

	    # -- article/back/ref-list/ref/label
	    my @labels = $refNode->findnodes($labelNodeXPath);
	    unless(length(@labels) <= 1) {
		warn "Multiple labels detected for a reference. First one is used.";
	    }
	    if(length(@labels) >= 1) {
		$refInfo->{label} = trim(asSingleLine(decodeStupidCharEntities($labels[0]->textContent)));
	    }

	    # -- article/back/ref-list/ref/mixed-citation
	    my @citations = $refNode->findnodes($mixedCitationNodeXPath);
	    unless(length(@citations) <= 1) {
		warn "Multiple citation texts detected for a reference. First one is used.";
	    }
	    if(length(@citations) >= 1) {
		$refInfo->{string} = trim(asSingleLine(decodeStupidCharEntities($citations[0]->textContent)));
	    }
	}		

	if(int(@refs) > 0) {
	    $articleInfo->{refs} = \@refs;
	}
    }
    return $articleInfo;
}

sub store # TODO: this should be a method of AbstractImporter.
{
    my ($self, $articleID, $articleInfo) = @_;

#    use Data::Dumper;
#    print Data::Dumper->Dump([$articleInfo]), "\n";

    unless($self->{db}->set($articleID, JSON::encode_json($articleInfo))) {
	die $self->{db}->error;
    }
}

sub trim
{
    my ($str) = @_;
    if(substr($str, 0, 1) eq "\n") {
	$str = substr($str, 1);
    }
    if(substr($str, -1, 1) eq "\n") {
	$str = substr($str, 0, length($str) - 1);
    }
    return $str;
}

sub asSingleLine
{
    my ($str) = @_;
    $str =~ s/\n/ /g;
    $str =~ s/ +/ /g;
    return $str;
}

sub decodeStupidCharEntities
{
    my ($str) = @_;
    my @chunks = split(/&#x(\d+);/, $str);
    # str charId str charId str charId

    my $decoded = '';
    for(my $i = 0; $i < int(@chunks); $i++) {

	if($i % 2 == 0) {
	    $decoded .= $chunks[$i];
	} else {
	    $decoded .= "\x{$chunks[$i]}";
	}
    }
    return $decoded;
}

1;
